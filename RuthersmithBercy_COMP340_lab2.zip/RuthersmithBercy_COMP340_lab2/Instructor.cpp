#include "Instructor.h"

Instructor::Instructor(std::string iName, std::string iEmail, std::string id) : Person (iName,iEmail){
		employeeId = id;
	};
