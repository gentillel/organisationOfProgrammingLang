#include "Person.h"

Person::Person(std::string pName, std::string email ){
		name = pName;
		emailAddress = email;
	};

Person::~Person(){}
