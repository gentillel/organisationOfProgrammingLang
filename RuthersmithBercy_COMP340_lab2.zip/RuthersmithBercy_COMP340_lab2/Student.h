#include <list>

class Student
{

private:
	std::string studentID;
	std::list<int>

public:
	Student();
	~Student();
	
};