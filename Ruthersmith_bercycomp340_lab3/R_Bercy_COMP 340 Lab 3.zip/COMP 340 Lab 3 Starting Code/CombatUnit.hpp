#ifndef COMBATUNIT_HPP
#define COMBATUNIT_HPP

class Item;

class CombatUnit {
public:
	CombatUnit(int health, int damage);
	virtual void UseItem(Item* item, CombatUnit* target) = 0;
	virtual void DealDamage(CombatUnit* target) = 0;
	virtual void PrintStats() = 0;
	int GetHealth();
	int GetDamage();
	void ModifyHealth(int amount);

protected:
	int health;
	int damage;
};

#endif