#include "CombatUnit.hpp"

CombatUnit::CombatUnit(int health, int damage) {
	this->health = health;
	this->damage = damage;
}

int CombatUnit::GetHealth() {
	return this->health;
}

int CombatUnit::GetDamage() {
	return this->damage;
}

void CombatUnit::ModifyHealth(int amount){
	this->health -= amount;
}