#ifndef PLAYER_HPP
#define PLAYER_HPP

#include "Item.hpp"
#include "CombatUnit.hpp"
#include <vector>
#include <string>

class Player : public CombatUnit {
public:
	Player(std::string name, int health, int damage);
	void AddItemToInventory(Item* item);
	void UseItem(Item* item, CombatUnit* target);
	void DealDamage(CombatUnit* target);
	void PrintStats();
private:
	std::string name;
	std::vector<Item*> inventory;
};

#endif