#include "Enemy.hpp"

Enemy::Enemy(int health, int damage, std::string type) : CombatUnit(health,damage) {
	this->type = type;
}


void Enemy::DealDamage(CombatUnit* target){
	std::cout<<this->type<<" attacks!"<<std::endl;
	target->ModifyHealth(this->damage);
}

void Enemy::UseItem(Item* item, CombatUnit* target){
	std::cout<<this->type<<" uses "<<item->GetName()<<std::endl;
	item->Effect(target);
}

void Enemy::PrintStats(){
	std::cout<<this->type<<"'s health: "<<this->health<<"\tDamage: "<<this->damage<<std::endl;
}