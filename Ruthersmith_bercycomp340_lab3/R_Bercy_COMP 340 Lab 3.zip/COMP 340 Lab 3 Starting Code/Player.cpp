#include "Player.hpp"

Player::Player(std::string name, int health, int damage) : CombatUnit(health,damage){
	this->name = name;
}


void Player::AddItemToInventory(Item* item){
	this->inventory.push_back(item);
}


void Player::DealDamage(CombatUnit* target){
	std::cout<<this->name<<" attacks!"<<std::endl;
	target->ModifyHealth(this->damage);
}

void Player::UseItem(Item* item, CombatUnit* target){
	std::cout<<this->name<<" uses "<<item->GetName()<<std::endl;
	item->Effect(target);
}

void Player::PrintStats(){
	std::cout<<this->name<<"'s health: "<<this->health<<"\tDamage: "<<this->damage<<std::endl<<std::endl;
}